/* fonts */
export const FontFamily = {
  interBold: "Inter-Bold",
  interMedium: "Inter-Medium",
  interSemiBold: "Inter-SemiBold",
};
/* font sizes */
export const FontSize = {
  size_xl: 20,
  size_3xs: 10,
  size_mini: 15,
};
/* Colors */
export const Color = {
  colorMediumslateblue: "#635bff",
  colorWhitesmoke: "#f6f9fc",
};
/* border radiuses */
export const Border = {
  br_xl: 20,
  br_5xs: 8,
  br_3xs: 10,
};
