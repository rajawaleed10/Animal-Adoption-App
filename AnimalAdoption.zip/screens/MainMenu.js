import * as React from "react";
import { Text, StyleSheet, View, TextInput, Pressable } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Border, FontSize, Color, FontFamily } from "../GlobalStyles";

const MainMenu = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.mainMenu}>
      <Text style={styles.findYourForever}>Find your forever friend !!!</Text>
      <Image
        style={[styles.mainMenuChild, styles.mainChildLayout5]}
        contentFit="cover"
        source={require("../assets/rectangle-7.png")}
      />
      <Image
        style={[styles.mainMenuItem, styles.mainChildLayout4]}
        contentFit="cover"
        source={require("../assets/rectangle-16.png")}
      />
      <Image
        style={[styles.mainMenuInner, styles.mainChildLayout3]}
        contentFit="cover"
        source={require("../assets/rectangle-25.png")}
      />
      <Image
        style={[styles.rectangleIcon, styles.mainChildLayout5]}
        contentFit="cover"
        source={require("../assets/rectangle-8.png")}
      />
      <Image
        style={[styles.mainMenuChild1, styles.mainChildLayout4]}
        contentFit="cover"
        source={require("../assets/rectangle-17.png")}
      />
      <Image
        style={[styles.mainMenuChild2, styles.mainChildLayout3]}
        contentFit="cover"
        source={require("../assets/rectangle-26.png")}
      />
      <Image
        style={[styles.mainMenuChild3, styles.mainChildLayout5]}
        contentFit="cover"
        source={require("../assets/rectangle-9.png")}
      />
      <Image
        style={[styles.mainMenuChild4, styles.mainChildLayout4]}
        contentFit="cover"
        source={require("../assets/rectangle-18.png")}
      />
      <Image
        style={[styles.mainMenuChild5, styles.mainChildLayout3]}
        contentFit="cover"
        source={require("../assets/rectangle-27.png")}
      />
      <LinearGradient
        style={[styles.rectangleLineargradient, styles.childBg]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.mainMenuChild6, styles.mainChildLayout1]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.mainMenuChild7, styles.mainChildLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.mainMenuChild8, styles.childBg]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.mainMenuChild9, styles.mainChildLayout1]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.mainMenuChild10, styles.mainChildLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.wrapper, styles.childLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput
          style={[styles.textinput, styles.iconLayout]}
          keyboardType="default"
          autoCapitalize="words"
        />
      </LinearGradient>
      <LinearGradient
        style={[styles.mainMenuChild11, styles.childBg]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.mainMenuChild12, styles.mainChildLayout1]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <LinearGradient
        style={[styles.mainMenuChild13, styles.mainChildLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      />
      <Text style={[styles.whiskersMcfluffles, styles.adoptTypo]}>
        Whiskers McFluffles
      </Text>
      <Pressable
        style={[styles.button1, styles.buttonPosition2]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button2, styles.buttonPosition2]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button3, styles.buttonPosition2]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button4, styles.buttonPosition1]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button5, styles.buttonPosition1]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button6, styles.buttonPosition1]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button7, styles.buttonPosition]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button8, styles.buttonPosition]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Pressable
        style={[styles.button9, styles.buttonPosition]}
        onPress={() => navigation.navigate("AdoptionPage")}
      >
        <LinearGradient
          style={[styles.button1Child, styles.childBg]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.adopt, styles.adoptTypo]}>ADOPT</Text>
      </Pressable>
      <Text style={[styles.sherlockWhiskers, styles.mochiMuffinTypo]}>
        Sherlock Whiskers
      </Text>
      <Text style={[styles.captainPatch, styles.lunaEclipseTypo]}>
        Captain Patch
      </Text>
      <Text style={[styles.lunaEclipse, styles.lunaEclipseTypo]}>
        Luna Eclipse
      </Text>
      <Text style={[styles.maverickZoom, styles.lunaEclipseTypo]}>
        Maverick Zoom
      </Text>
      <Text style={[styles.scoutWagtail, styles.mochiMuffinTypo]}>
        Scout Wagtail
      </Text>
      <Text style={[styles.mochiMuffin, styles.mochiMuffinTypo]}>
        Mochi Muffin
      </Text>
      <Text style={[styles.lunaBeans, styles.adoptTypo]}>Luna Beans</Text>
      <Text style={[styles.emberPawz, styles.adoptTypo]}>Ember Pawz</Text>
      <Pressable
        style={styles.container}
        onPress={() => navigation.navigate("Profile")}
      >
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/frame-2.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  mainChildLayout5: {
    height: 104,
    borderRadius: Border.br_3xs,
    top: 191,
    width: 107,
    position: "absolute",
  },
  mainChildLayout4: {
    top: 419,
    height: 104,
    width: 107,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  mainChildLayout3: {
    top: 647,
    height: 104,
    width: 107,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  childBg: {
    backgroundColor: "transparent",
    borderRadius: Border.br_5xs,
  },
  mainChildLayout1: {
    top: 549,
    backgroundColor: "transparent",
    height: 30,
    borderRadius: Border.br_5xs,
    width: 107,
    position: "absolute",
  },
  mainChildLayout: {
    top: 777,
    backgroundColor: "transparent",
    height: 30,
    borderRadius: Border.br_5xs,
    width: 107,
    position: "absolute",
  },
  childLayout: {
    height: 30,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  adoptTypo: {
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textTransform: "capitalize",
    position: "absolute",
  },
  buttonPosition2: {
    top: 363,
    height: 30,
    width: 107,
    position: "absolute",
  },
  buttonPosition1: {
    top: 591,
    height: 30,
    width: 107,
    position: "absolute",
  },
  buttonPosition: {
    top: 819,
    height: 30,
    width: 107,
    position: "absolute",
  },
  mochiMuffinTypo: {
    top: 558,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textTransform: "capitalize",
    position: "absolute",
  },
  lunaEclipseTypo: {
    top: 786,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textTransform: "capitalize",
    position: "absolute",
  },
  findYourForever: {
    top: 141,
    fontSize: FontSize.size_xl,
    width: 383,
    textAlign: "left",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textTransform: "capitalize",
    left: 23,
    position: "absolute",
  },
  mainMenuChild: {
    left: 23,
  },
  mainMenuItem: {
    left: 23,
  },
  mainMenuInner: {
    left: 23,
  },
  rectangleIcon: {
    left: 161,
  },
  mainMenuChild1: {
    left: 161,
  },
  mainMenuChild2: {
    left: 161,
  },
  mainMenuChild3: {
    left: 299,
  },
  mainMenuChild4: {
    left: 299,
  },
  mainMenuChild5: {
    left: 299,
  },
  rectangleLineargradient: {
    height: 30,
    position: "absolute",
    top: 321,
    borderRadius: Border.br_5xs,
    width: 107,
    left: 23,
  },
  mainMenuChild6: {
    left: 23,
  },
  mainMenuChild7: {
    left: 23,
  },
  mainMenuChild8: {
    height: 30,
    position: "absolute",
    top: 321,
    borderRadius: Border.br_5xs,
    width: 107,
    left: 161,
  },
  mainMenuChild9: {
    left: 161,
  },
  mainMenuChild10: {
    left: 161,
  },
  textinput: {
    backgroundColor: "transparent",
    borderRadius: Border.br_5xs,
  },
  wrapper: {
    left: 92,
    top: 89,
    width: 245,
  },
  mainMenuChild11: {
    height: 30,
    position: "absolute",
    top: 321,
    borderRadius: Border.br_5xs,
    width: 107,
    left: 299,
  },
  mainMenuChild12: {
    left: 299,
  },
  mainMenuChild13: {
    left: 299,
  },
  whiskersMcfluffles: {
    left: 26,
    top: 330,
    fontSize: FontSize.size_3xs,
  },
  button1Child: {
    top: 0,
    left: 0,
    height: 30,
    position: "absolute",
    width: 107,
    borderRadius: Border.br_5xs,
  },
  adopt: {
    top: 9,
    left: 36,
  },
  button1: {
    left: 23,
  },
  button2: {
    left: 161,
  },
  button3: {
    left: 299,
  },
  button4: {
    left: 23,
  },
  button5: {
    left: 161,
  },
  button6: {
    left: 299,
  },
  button7: {
    left: 23,
  },
  button8: {
    left: 161,
  },
  button9: {
    left: 299,
  },
  sherlockWhiskers: {
    left: 31,
  },
  captainPatch: {
    left: 42,
  },
  lunaEclipse: {
    left: 184,
  },
  maverickZoom: {
    left: 315,
  },
  scoutWagtail: {
    left: 180,
  },
  mochiMuffin: {
    left: 320,
  },
  lunaBeans: {
    left: 186,
    top: 330,
    fontSize: FontSize.size_3xs,
  },
  emberPawz: {
    left: 322,
    top: 330,
    fontSize: FontSize.size_3xs,
  },
  container: {
    left: 355,
    top: 79,
    width: 51,
    height: 51,
    position: "absolute",
  },
  mainMenu: {
    backgroundColor: Color.colorMediumslateblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default MainMenu;
