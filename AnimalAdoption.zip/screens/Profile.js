import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const Profile = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.profile}>
      <Image
        style={styles.profileChild}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Text style={styles.tommySBailes}>Tommy S. Bailes</Text>
      <View style={[styles.address, styles.numberPosition]}>
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout1]}
          contentFit="cover"
          source={require("../assets/vector.png")}
        />
        <Image
          style={[styles.vectorIcon1, styles.vectorIconLayout1]}
          contentFit="cover"
          source={require("../assets/vector1.png")}
        />
        <Image
          style={[styles.vectorIcon2, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector2.png")}
        />
        <Image
          style={[styles.vectorIcon3, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector3.png")}
        />
        <Image
          style={[styles.vectorIcon4, styles.vectorIconPosition3]}
          contentFit="cover"
          source={require("../assets/vector4.png")}
        />
        <Image
          style={[styles.vectorIcon5, styles.vectorIconPosition2]}
          contentFit="cover"
          source={require("../assets/vector5.png")}
        />
        <Image
          style={[styles.vectorIcon6, styles.vectorIconPosition2]}
          contentFit="cover"
          source={require("../assets/vector6.png")}
        />
        <Text style={styles.northwestBoulevardTeterboro}>
          3013 Northwest Boulevard Teterboro, NJ 07608
        </Text>
      </View>
      <View style={styles.email}>
        <Image
          style={[styles.vectorIcon7, styles.vectorIconPosition1]}
          contentFit="cover"
          source={require("../assets/vector7.png")}
        />
        <Image
          style={[styles.vectorIcon8, styles.vectorIconPosition]}
          contentFit="cover"
          source={require("../assets/vector8.png")}
        />
        <Image
          style={[styles.vectorIcon9, styles.vectorIconPosition1]}
          contentFit="cover"
          source={require("../assets/vector9.png")}
        />
        <Image
          style={[styles.vectorIcon10, styles.vectorIconPosition]}
          contentFit="cover"
          source={require("../assets/vector10.png")}
        />
        <Image
          style={[styles.vectorIcon11, styles.vectorIconPosition]}
          contentFit="cover"
          source={require("../assets/vector11.png")}
        />
        <Text style={[styles.tommysbailesdayrepcom, styles.textTypo]}>
          TommySBailes@dayrep.com
        </Text>
      </View>
      <View style={[styles.number, styles.numberPosition]}>
        <Image
          style={[styles.vectorIcon12, styles.vectorIconPosition3]}
          contentFit="cover"
          source={require("../assets/vector12.png")}
        />
        <Image
          style={[styles.vectorIcon13, styles.vectorIconLayout1]}
          contentFit="cover"
          source={require("../assets/vector13.png")}
        />
        <Image
          style={[styles.vectorIcon14, styles.vectorIconLayout1]}
          contentFit="cover"
          source={require("../assets/vector14.png")}
        />
        <Text style={[styles.text, styles.textTypo]}>+1 201-966-3915</Text>
      </View>
      <Pressable
        style={[styles.logout, styles.logoutLayout]}
        onPress={() => navigation.navigate("Login")}
      >
        <LinearGradient
          style={[styles.logoutChild, styles.logoutLayout]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={styles.logout1}>Logout</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  numberPosition: {
    left: "5.58%",
    right: "5.35%",
    width: "89.07%",
    position: "absolute",
  },
  vectorIconLayout1: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconLayout: {
    top: "49.79%",
    width: "0.81%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconPosition3: {
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconPosition2: {
    top: "2.08%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconPosition1: {
    right: "90.31%",
    width: "9.69%",
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  vectorIconPosition: {
    left: "1.75%",
    right: "92.09%",
    width: "6.15%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  textTypo: {
    textTransform: "lowercase",
    width: 314,
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    textAlign: "left",
    color: Color.colorWhitesmoke,
    position: "absolute",
  },
  logoutLayout: {
    height: 48,
    width: 168,
    position: "absolute",
  },
  profileChild: {
    top: 106,
    width: 176,
    height: 171,
    left: 24,
    position: "absolute",
  },
  tommySBailes: {
    top: 335,
    fontSize: 30,
    width: 383,
    textAlign: "left",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textTransform: "capitalize",
    left: 24,
    position: "absolute",
  },
  vectorIcon: {
    height: "35.83%",
    width: "7.34%",
    top: "31.88%",
    right: "91.44%",
    left: "1.23%",
    bottom: "32.29%",
  },
  vectorIcon1: {
    height: "29.79%",
    width: "8.98%",
    top: "5%",
    bottom: "65.21%",
    left: "0.42%",
    right: "90.6%",
  },
  vectorIcon2: {
    height: "17.92%",
    right: "93.47%",
    left: "5.72%",
    bottom: "32.29%",
  },
  vectorIcon3: {
    height: "6.04%",
    right: "95.93%",
    bottom: "44.17%",
    left: "3.26%",
  },
  vectorIcon4: {
    width: "9.79%",
    top: "67.71%",
    right: "90.21%",
    bottom: "28.13%",
    height: "4.17%",
  },
  vectorIcon5: {
    height: "25%",
    width: "1.62%",
    right: "97.15%",
    bottom: "72.92%",
    left: "1.23%",
  },
  vectorIcon6: {
    width: "3.26%",
    right: "96.32%",
    bottom: "93.75%",
    height: "4.17%",
    left: "0.42%",
  },
  northwestBoulevardTeterboro: {
    width: 314,
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    left: 69,
    top: 0,
    textAlign: "left",
    color: Color.colorWhitesmoke,
    textTransform: "capitalize",
    position: "absolute",
  },
  address: {
    height: "5.15%",
    top: "43.56%",
    bottom: "51.29%",
  },
  vectorIcon7: {
    height: "98.33%",
    bottom: "1.67%",
    top: "0%",
  },
  vectorIcon8: {
    height: "30.83%",
    bottom: "69.17%",
    top: "0%",
  },
  vectorIcon9: {
    height: "49.17%",
    top: "12.5%",
    bottom: "38.33%",
  },
  vectorIcon10: {
    height: "8.33%",
    bottom: "91.67%",
    top: "0%",
  },
  vectorIcon11: {
    height: "68.33%",
    top: "30.42%",
    bottom: "1.25%",
  },
  tommysbailesdayrepcom: {
    left: 68,
    top: 0,
  },
  email: {
    height: "2.58%",
    width: "88.84%",
    top: "52.47%",
    right: "5.47%",
    bottom: "44.96%",
    left: "5.7%",
    position: "absolute",
  },
  vectorIcon12: {
    height: "100%",
    width: "9.4%",
    bottom: "0%",
    top: "0%",
    right: "90.6%",
  },
  vectorIcon13: {
    height: "9.59%",
    width: "4.07%",
    right: "93.26%",
    bottom: "90.41%",
    left: "2.66%",
    top: "0%",
  },
  vectorIcon14: {
    height: "4.08%",
    width: "1.33%",
    top: "86.33%",
    right: "94.65%",
    bottom: "9.59%",
    left: "4.02%",
  },
  text: {
    top: 13,
    left: 69,
    textTransform: "lowercase",
  },
  number: {
    height: "5.26%",
    top: "58.8%",
    bottom: "35.94%",
  },
  logoutChild: {
    left: 0,
    borderRadius: Border.br_xl,
    backgroundColor: "transparent",
    top: 0,
  },
  logout1: {
    top: 12,
    left: 49,
    textAlign: "center",
    fontSize: FontSize.size_xl,
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  logout: {
    top: 632,
    left: 131,
  },
  profile: {
    backgroundColor: Color.colorMediumslateblue,
    flex: 1,
    width: "100%",
    height: 932,
    overflow: "hidden",
  },
});

export default Profile;
