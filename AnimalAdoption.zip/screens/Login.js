import React, { useState } from "react";
import { Text, StyleSheet, TextInput, Pressable, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const Login = () => {
  const [rectangleTextInput1, setRectangleTextInput1] = useState("Password");
  const navigation = useNavigation();

  return (
    <View style={styles.login}>
      <Text style={styles.welcomeBackAnimalLover}>
        Welcome back, animal lover!
      </Text>
      <Text style={styles.letsWagThis}>
        Let's wag this adoption journey together!
      </Text>
      <Text style={[styles.email, styles.emailTypo]}>Email</Text>
      <Text style={[styles.password, styles.emailTypo]}>Password</Text>
      <LinearGradient
        style={[styles.wrapper, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput
          style={styles.textinput}
          keyboardType="email-address"
          autoCapitalize="none"
        />
      </LinearGradient>
      <LinearGradient
        style={[styles.container, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput
          style={styles.textinput}
          value={rectangleTextInput1}
          onChangeText={setRectangleTextInput1}
          secureTextEntry={true}
        />
      </LinearGradient>
      <Pressable
        style={[styles.button, styles.buttonLayout]}
        onPress={() => navigation.navigate("MainMenu")}
      >
        <LinearGradient
          style={[styles.buttonChild, styles.buttonChildPosition]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.login1, styles.login1Typo]}>Login</Text>
      </Pressable>
      <Image
        style={[styles.beautifulPetPortraitOfDog, styles.buttonChildPosition]}
        contentFit="cover"
        source={require("../assets/beautiful-pet-portrait-of-dog.png")}
      />
      <Image
        style={[styles.googleIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/google.png")}
      />
      <Image
        style={[styles.facebookIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/facebook.png")}
      />
      <Pressable
        style={[styles.button1, styles.buttonLayout]}
        onPress={() => navigation.navigate("SignUp")}
      >
        <LinearGradient
          style={[styles.buttonChild, styles.buttonChildPosition]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.signup, styles.login1Typo]}>SIGNUP</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  emailTypo: {
    textAlign: "left",
    left: 96,
    fontSize: FontSize.size_mini,
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  wrapperLayout: {
    height: 30,
    width: 239,
    left: 96,
    position: "absolute",
  },
  buttonLayout: {
    height: 48,
    width: 168,
  },
  buttonChildPosition: {
    left: 0,
    position: "absolute",
  },
  login1Typo: {
    top: 12,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "45.39%",
    top: "49.03%",
    height: "5.58%",
    position: "absolute",
    overflow: "hidden",
  },
  welcomeBackAnimalLover: {
    top: 112,
    width: 383,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    left: 23,
    position: "absolute",
  },
  letsWagThis: {
    top: 148,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    fontSize: FontSize.size_mini,
    width: 383,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    left: 23,
    position: "absolute",
  },
  email: {
    top: 214,
  },
  password: {
    top: 285,
  },
  textinput: {
    borderRadius: Border.br_5xs,
    height: "100%",
    backgroundColor: "transparent",
    width: "100%",
  },
  wrapper: {
    top: 243,
  },
  container: {
    top: 314,
  },
  buttonChild: {
    top: 0,
    borderRadius: Border.br_xl,
    height: 48,
    width: 168,
    backgroundColor: "transparent",
  },
  login1: {
    left: 56,
  },
  button: {
    top: 377,
    left: 131,
    position: "absolute",
    width: 168,
  },
  beautifulPetPortraitOfDog: {
    top: 613,
    width: 274,
    height: 319,
  },
  googleIcon: {
    width: "12.09%",
    right: "54.88%",
    left: "33.02%",
  },
  facebookIcon: {
    width: "12.56%",
    right: "32.79%",
    left: "54.65%",
  },
  signup: {
    left: 45,
  },
  button1: {
    top: 534,
    left: 129,
    position: "absolute",
    width: 168,
  },
  login: {
    backgroundColor: Color.colorMediumslateblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default Login;
