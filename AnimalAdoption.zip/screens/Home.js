import * as React from "react";
import { Pressable, StyleSheet, View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Home = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.home}>
      <Pressable
        style={[styles.cta1, styles.ctaLayout]}
        onPress={() => navigation.navigate("Login")}
      >
        <LinearGradient
          style={[styles.cta1Child, styles.cta1ChildPosition]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.login, styles.loginTypo]}>LOGIN</Text>
      </Pressable>
      <Pressable
        style={[styles.cta2, styles.ctaLayout]}
        onPress={() => navigation.navigate("SignUp")}
      >
        <LinearGradient
          style={[styles.cta1Child, styles.cta1ChildPosition]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={[styles.signup, styles.loginTypo]}>SIGNUP</Text>
      </Pressable>
      <Image
        style={[styles.groupPortraitOfAdorablePup, styles.cta1ChildPosition]}
        contentFit="cover"
        source={require("../assets/group-portrait-of-adorable-puppies.png")}
      />
      <Text style={[styles.waggleWooContainer, styles.loginTypo]}>
        <Text style={styles.waggleWoo}>{`Waggle & Woo! Pets
`}</Text>
        <Text style={styles.rescueNotRetail}>Rescue, not retail</Text>
      </Text>
      <Image
        style={styles.theHappyTailProject1}
        contentFit="cover"
        source={require("../assets/the-happy-tail-project-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  ctaLayout: {
    height: 48,
    width: 168,
  },
  cta1ChildPosition: {
    left: 0,
    position: "absolute",
  },
  loginTypo: {
    textAlign: "center",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  cta1Child: {
    top: 0,
    borderRadius: Border.br_xl,
    backgroundColor: "transparent",
    height: 48,
    width: 168,
  },
  login: {
    left: 53,
    fontSize: FontSize.size_xl,
    top: 12,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  cta1: {
    top: 465,
    left: 131,
    width: 168,
    position: "absolute",
  },
  signup: {
    left: 45,
    fontSize: FontSize.size_xl,
    top: 12,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  cta2: {
    top: 543,
    left: 131,
    width: 168,
    position: "absolute",
  },
  groupPortraitOfAdorablePup: {
    top: 785,
    width: 430,
    height: 146,
  },
  waggleWoo: {
    fontSize: FontSize.size_xl,
  },
  rescueNotRetail: {
    fontSize: FontSize.size_mini,
  },
  waggleWooContainer: {
    top: 340,
    left: 117,
  },
  theHappyTailProject1: {
    top: 151,
    left: 123,
    width: 185,
    height: 176,
    position: "absolute",
  },
  home: {
    backgroundColor: Color.colorMediumslateblue,
    flex: 1,
    width: "100%",
    height: 932,
    overflow: "hidden",
  },
});

export default Home;
