import * as React from "react";
import { Text, StyleSheet, Pressable, View } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const AdoptionPage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.adoptionPage}>
      <Text style={[styles.thankYou, styles.thankYouTypo]}>THANK YOU</Text>
      <Text
        style={[styles.thePetIs, styles.thankYouTypo]}
      >{`THE PET IS ON THE WAY. 
TAKE GOOD CARE`}</Text>
      <Image
        style={styles.domesticCuteDog}
        contentFit="cover"
        source={require("../assets/domestic-cute-dog.png")}
      />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Profile")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/frame-2.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  thankYouTypo: {
    width: 383,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textTransform: "capitalize",
    left: "50%",
    marginLeft: -191,
    position: "absolute",
  },
  thankYou: {
    fontSize: 63,
    color: "#fff",
    textAlign: "left",
    top: 264,
  },
  thePetIs: {
    top: 387,
    fontSize: FontSize.size_xl,
    color: Color.colorWhitesmoke,
    textAlign: "center",
  },
  domesticCuteDog: {
    left: 0,
    width: 430,
    height: 668,
    top: 264,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 352,
    top: 79,
    width: 51,
    height: 51,
    position: "absolute",
  },
  adoptionPage: {
    backgroundColor: Color.colorMediumslateblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default AdoptionPage;
