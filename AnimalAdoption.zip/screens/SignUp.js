import React, { useState } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, TextInput, Pressable, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const SignUp = () => {
  const [rectangleTextInput5, setRectangleTextInput5] = useState("Password");
  const navigation = useNavigation();

  return (
    <View style={styles.signup}>
      <Image
        style={styles.grayKittyWithMonochromeWal}
        contentFit="cover"
        source={require("../assets/gray-kitty-with-monochrome-wall-behind-her.png")}
      />
      <Text
        style={styles.joinOurWaggle}
      >{`Join our Waggle & Woo! Pets community and change a life.`}</Text>
      <Text style={styles.createAFree}>
        Create a free account to start your adoption journey.
      </Text>
      <Text style={[styles.firstName, styles.nameTypo]}>First Name</Text>
      <Text style={[styles.lastName, styles.nameTypo]}>Last Name</Text>
      <Text style={[styles.email, styles.nameTypo]}>Email</Text>
      <Text style={[styles.phoneNumber, styles.nameTypo]}>Phone Number</Text>
      <Text style={[styles.password, styles.nameTypo]}>Password</Text>
      <Text style={[styles.confirmPassword, styles.nameTypo]}>
        Confirm Password
      </Text>
      <LinearGradient
        style={[styles.wrapper, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput
          style={styles.textinput}
          keyboardType="default"
          autoCapitalize="characters"
          multiline={false}
          secureTextEntry={false}
        />
      </LinearGradient>
      <LinearGradient
        style={[styles.container, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput style={styles.textinput} autoCapitalize="characters" />
      </LinearGradient>
      <LinearGradient
        style={[styles.frame, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput style={styles.textinput} keyboardType="email-address" />
      </LinearGradient>
      <LinearGradient
        style={[styles.rectangleLineargradient, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput style={styles.textinput} keyboardType="phone-pad" />
      </LinearGradient>
      <LinearGradient
        style={[styles.wrapper1, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput style={styles.textinput} secureTextEntry={true} />
      </LinearGradient>
      <LinearGradient
        style={[styles.wrapper2, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
      >
        <TextInput
          style={styles.textinput}
          value={rectangleTextInput5}
          onChangeText={setRectangleTextInput5}
          keyboardType="default"
          secureTextEntry={true}
        />
      </LinearGradient>
      <Pressable
        style={[styles.button, styles.buttonLayout]}
        onPress={() => navigation.navigate("Login")}
      >
        <LinearGradient
          style={[styles.buttonChild, styles.buttonLayout]}
          locations={[0, 1]}
          colors={["rgba(246, 249, 252, 0.4)", "rgba(246, 249, 252, 0.4)"]}
        />
        <Text style={styles.signup1}>SIGNUP</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  nameTypo: {
    textAlign: "left",
    left: 96,
    fontSize: FontSize.size_mini,
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  wrapperLayout: {
    height: 30,
    width: 239,
    left: 96,
    position: "absolute",
  },
  buttonLayout: {
    height: 48,
    width: 168,
    position: "absolute",
  },
  grayKittyWithMonochromeWal: {
    top: 562,
    width: 310,
    height: 380,
    left: 0,
    position: "absolute",
  },
  joinOurWaggle: {
    top: 80,
    width: 383,
    left: 23,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  createAFree: {
    top: 140,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    fontSize: FontSize.size_mini,
    width: 383,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    left: 23,
    position: "absolute",
  },
  firstName: {
    top: 201,
  },
  lastName: {
    top: 272,
  },
  email: {
    top: 343,
  },
  phoneNumber: {
    top: 413,
  },
  password: {
    top: 483,
  },
  confirmPassword: {
    top: 553,
  },
  textinput: {
    borderRadius: Border.br_5xs,
    height: "100%",
    backgroundColor: "transparent",
    width: "100%",
  },
  wrapper: {
    top: 230,
  },
  container: {
    top: 301,
  },
  frame: {
    top: 372,
  },
  rectangleLineargradient: {
    top: 442,
  },
  wrapper1: {
    top: 512,
  },
  wrapper2: {
    top: 582,
  },
  buttonChild: {
    top: 0,
    borderRadius: Border.br_xl,
    backgroundColor: "transparent",
    left: 0,
  },
  signup1: {
    top: 12,
    left: 45,
    textAlign: "center",
    color: Color.colorWhitesmoke,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  button: {
    top: 643,
    left: 100,
  },
  signup: {
    backgroundColor: Color.colorMediumslateblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default SignUp;
